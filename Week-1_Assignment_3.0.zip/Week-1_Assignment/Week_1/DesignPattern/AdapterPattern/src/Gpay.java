public class Gpay {
    public void doPayment(double amount) {
        System.out.println("Payment of " + amount + " rs made through Gpay.");
    }
}
