public class Stripe {
    public void executePayment(double amount) {
        System.out.println("Payment of " + amount + " rs made through Stripe.");
    }
}