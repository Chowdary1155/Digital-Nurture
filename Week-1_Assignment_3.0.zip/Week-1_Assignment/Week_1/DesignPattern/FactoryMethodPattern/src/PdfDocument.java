public interface PdfDocument extends Document {

}
