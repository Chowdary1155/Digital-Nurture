public interface WordDocument extends Document{

}
